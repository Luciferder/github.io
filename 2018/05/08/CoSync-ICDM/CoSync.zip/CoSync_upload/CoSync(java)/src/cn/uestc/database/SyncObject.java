package cn.uestc.database;

import java.util.ArrayList;


public class SyncObject{
    public double[] data; 
    public int id;
    public int clusterID = -1;
    public int label = -1; // label of the SyncObject



    

    
    public SyncObject() {
    	
    }
        
    
    public SyncObject( int id, double[] data) {
    	this.data = data;
    	this.id = id;  
    }    
    
    
}