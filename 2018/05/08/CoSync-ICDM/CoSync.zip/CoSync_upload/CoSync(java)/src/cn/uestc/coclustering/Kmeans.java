package cn.uestc.coclustering;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import weka.clusterers.SimpleKMeans;
import weka.core.DistanceFunction;
import weka.core.EuclideanDistance;
import weka.core.Instances;

public class Kmeans {
	public static void main(String[] args) {  
        Instances ins = null;  
        SimpleKMeans KM = null;  
          
        // Ŀǰû��ʹ�õ���������3.7.10�İ汾֮�п���ָ�������㷨  
        // Ĭ����ŷ����þ���  
        DistanceFunction disFun = null;  
          
        try {  
            // ������������  
            ins = new Instances(new BufferedReader(new FileReader(new File("E:/Data/Lung/Lung.arff"))));
            BufferedReader br = new BufferedReader(new FileReader(new File("E:/Data/Lung/Indication.txt")));
            String line;
            int indication[] = null;
            while((line = br.readLine()) != null){
            	String[] strs = line.trim().split("\\s+");
            	indication = new int[strs.length];
            	int i =0;
            	for(String str : strs){
            		indication[i++] = Integer.parseInt(str);
            	}
            }
            
            // ��ʼ�������� �������㷨��  
            KM = new SimpleKMeans();  
            KM.setNumClusters(2);       //���þ���Ҫ�õ����������
            // ��ӡ������  
            System.out.println("KM is running...");  
//            ins.setClass(ins.attribute(2000));
            ins.deleteAttributeAt(ins.numAttributes()-1);
            for(int i = 0,j = 0;i < indication.length;i++){
            	if(indication[i]  == 0 ){
            		ins.deleteAttributeAt(i-j);
            		j++;
            	}
            }
            System.out.println("num of dim = " + ins.numAttributes());
            KM.setPreserveInstancesOrder(true);
			KM.setSeed((new Random()).nextInt(200));
			KM.setMaxIterations(100);
			KM.setDistanceFunction(new EuclideanDistance());
			KM.setPreserveInstancesOrder(true);
			
            KM.buildClusterer(ins);     //��ʼ���о���  
            
            HashMap<Integer, Integer> clusterInfo = new HashMap<Integer, Integer>();
            int[] assignments = KM.getAssignments();
			int i=0;
			for(int clusterNum : assignments)
				clusterInfo.put(i++, clusterNum);
			for(Map.Entry<Integer, Integer> entry: clusterInfo.entrySet()){
				System.out.println("key= " + entry.getKey() + " and value= " + entry.getValue());
			}
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File("E:/Data/Lung/KMresult.txt")));
			for(int ij : assignments){
				System.out.print( ij + "  ");
				bw.write(ij + " ");
			}
			bw.flush();
			bw.close();
//          for(String option : KM.getOptions()) {  
//              System.out.println(option);  
//          }  
//          System.out.println("CentroIds:" + tempIns);  
        } catch(Exception e) {  
            e.printStackTrace();  
        }  
    } 
}

