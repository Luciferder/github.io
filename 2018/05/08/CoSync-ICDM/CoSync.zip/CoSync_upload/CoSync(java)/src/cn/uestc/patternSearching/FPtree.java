package cn.uestc.patternSearching;

import java.util.Comparator;
import java.util.HashSet;

public class FPtree {
	ManyTreeNode root;
	int[][] table;
	Integer[] orderList;
	int maxSize;
	HashSet<Integer> rowSet;
	HashSet<Integer> colSet;
	HashSet<Integer> removedSet;
	
	public FPtree(int[][] table, Integer[]orderList, Comparator<Integer> comparator){
		this.table = table;
		this.orderList = orderList;
		root = new ManyTreeNode(0, comparator);
		root.setLevel(0);
		maxSize = 0;
		removedSet = new HashSet<Integer>();
		for(int row = 1;row<table.length;row++){
			int[] transition = table[row];
			ManyTreeNode parent = root;
			for(int i=1; i< orderList.length;i++){
				int nowcol = orderList[i];
				ManyTreeNode nownode;
				if(1 == transition[nowcol]){
					if(!parent.containChild(nowcol)){
						nownode = parent.addChild(nowcol, row);
					}else{
						nownode = parent.getChild(nowcol);
						nownode.addCount(1,row);
					}
					parent = nownode;
				}
			}
		}
	}
	
	public ManyTreeNode graftBranch(ManyTreeNode sourceNode, ManyTreeNode desNode){
		if(desNode.containChild(sourceNode.getID())){
			ManyTreeNode objectNode = desNode.getChild(sourceNode.getID());
			objectNode.addCount(sourceNode.getCount(),sourceNode.getRowSet());
			for(ManyTreeNode childOfSourceNode:sourceNode.getChildList()){
				graftBranch(childOfSourceNode,objectNode);
			}
			sourceNode = null;
		}else{
			desNode.addChild(sourceNode);
		}
		return desNode;
	}
	
	
	public int getMaxSizeFromBranch(ManyTreeNode rootNode,int minNum, int minDim){
		if(rootNode.getCount() < minNum){
			return 0;
		}
		if(rootNode.getLevel() >= minDim){
			int temp = rootNode.getCount() * rootNode.getLevel();
			if(temp > maxSize){
				colSet = rootNode.getColSet();
				rowSet = rootNode.getRowSet();
				maxSize = temp;
			}
		}
		
		for(ManyTreeNode child:rootNode.getChildList()){
			if(rootNode.lazy){
				child.lazy = true;
				child.setLevel(rootNode.getLevel()+1);
			}
			int temp = getMaxSizeFromBranch(child, minNum, minDim);
//			if(temp > maxSize){
//				maxSize = temp;
//				colSet = child.getColSet();
//				rowSet = child.getRowSet();
//			}
		}
		return maxSize;
	}
}
