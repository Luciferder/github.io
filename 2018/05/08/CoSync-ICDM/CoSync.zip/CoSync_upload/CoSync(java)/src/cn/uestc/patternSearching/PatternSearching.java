package cn.uestc.patternSearching;

import cn.uestc.database.SyncObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
/**
 * @author Chongming Gao
 * @version 1.0
 * @Notation The ordinal number of matrix in this class begin at 1 not 0, in turn, the size of matrix is table[num+1][dim+1].  
 */
public class PatternSearching {
	double[][] data;
	int num;
	int dim;
	int minNum;
	int minDim;
	HashSet<Double> valueList;
	Integer[] orderList;		//order list table,for example, the 2nd dimension is 5th biggest, so orderlist[5] = 2; note orderList[0] remains unuse;
	int[][] table;
	int[] sumNumCount;
	int[] sumDimCount;
	public HashSet<Integer> rowSet;
	public HashSet<Integer> colSet;
	public int maxSize;
	private TreeSet<ColRowSet> colRowSet;
	double particularNumber;
	
	/**
	 * @author Chongming Gao
	 * @Notation ��������Co-Sync�Ľ��ArrayList<SyncObject>����������Ϊdouble[][]�����ݽṹ���������е�value����valueList�С�
	 */
	public PatternSearching(ArrayList<SyncObject> data, int minNum, int minDim) throws IOException {
		this.num = data.size();
		this.dim = data.get(0).data.length;
		this.minDim = minDim;
		this.minNum = minNum;
		this.data = new double[num + 1][];
		valueList = new HashSet<Double>();
		for(int i=0;i<data.size();i++){
			this.data[i+1] = new double[dim+1];
			for(int j = 0; j < dim;j++){
				this.data[i+1][j+1] = data.get(i).data[j];
				if(!valueList.contains(this.data[i+1][j+1])){
					valueList.add(this.data[i+1][j+1]);
				}
			}
		}
		colRowSet = new TreeSet<ColRowSet>();
		for(double i : valueList){
			particularNumber = i;
			maxSize = 0;
			colSet = null;
			rowSet = null;
			getMaxSize(particularNumber);
			if(null == colSet || null == rowSet){
				continue;
			}
		}

	}
	

//	private double[][] filterAccordingToMinnum_MinCol(double particularNumber){
//		int[] sumNumCount = new int[dim+1];
//		int[] sumDimCount = new int[num+1];
//		for(int i=1;i<data.length;i++){
//			for(int j=1;j<data[0].length;j++){
//				if(data[i][j] == particularNumber){
//					sumNumCount[i]++;
//					sumDimCount[j]++;
//				}
//			}
//		}
//		for(int i = 1;i<sumNumCount.length;i++){
//			if(sumNumCount[i] < min_dim){
//				
//			}
//		}
//		return data_AfterFilerting;
//	}
	
	public Integer[] getorderlist(int[] sumDimCount,IndexComparator comparator){
		Integer[] indexes = comparator. indexGenerator();
		Arrays.sort(indexes,1,sumDimCount.length,comparator);
		return indexes;
	}
	
	public int[][] getEachTable(double particularNumber){
		table = new int[num+1][dim+1];
		sumNumCount = new int[num+1];
		sumDimCount = new int[dim+1];
		
		for(int i=1;i<data.length;i++){
			for(int j=1;j<data[1].length;j++){
				if(data[i][j] == particularNumber){
					sumNumCount[i]++;
					sumDimCount[j]++;
					table[i][j] = 1;
				}
			}
		}
		
		return table;
	}
	
	public int getMaxSize(double particularNumber){
		table = getEachTable(particularNumber);
		IndexComparator comparator = new IndexComparator(sumDimCount);
		orderList = getorderlist(sumDimCount,comparator);
		FPtree fptree = new FPtree(table,orderList,comparator);
		searchingPatternOnFPTree(fptree);
		if(colSet != null && rowSet != null)
			colRowSet.add(new ColRowSet(particularNumber,colSet,rowSet));
		fptree = null;
		return maxSize;
	}


	public int searchingPatternOnFPTree(FPtree fptree){
		while(!fptree.root.getChildList().isEmpty()){
			ManyTreeNode node = fptree.root.getChildList().poll();
			int temp = fptree.getMaxSizeFromBranch(node, minNum, minDim);
			if(temp > maxSize){
				maxSize = temp;
				colSet = fptree.colSet;
				rowSet = fptree.rowSet;
			}

			for(ManyTreeNode child: node.getChildList()){
				fptree.graftBranch(child, fptree.root);
			}
			fptree.removedSet.add(node.getID());
			node = null;
		}
		return maxSize;
	}
	
	
	
	
	public static void main(String[] args) throws IOException {
		double[][] matrix = {
				{1,1,1,0,0},
				{0,1,1,0,1},
				{1,0,1,1,1},
				{1,0,0,1,1},
				{1,1,1,0,0},
				{1,1,1,0,1},
				{1,0,0,0,0},
				{1,1,1,0,0},
				{1,1,0,0,1},
				{0,1,1,1,0},
				{1,0,0,0,0},
				{1,0,0,0,0},
				{0,1,1,0,0}
				};
		ArrayList<SyncObject> data = new ArrayList<SyncObject>(10);
		for(int i = 1;i<=matrix.length;i++){
			data.add(new SyncObject(i,matrix[i-1]));
		}
		
		PatternSearching ps = new PatternSearching(data,1,1);
		ps.getSet();
	}
	
	public void getSet(){
		System.out.println("Number of distinct values: " + colRowSet.size());
		int cnt = 1;
		for(ColRowSet set: colRowSet){
			System.out.println("\n======================================================================");
			System.out.println("["+ cnt++ +"]");
			System.out.println("size = " + set.size);
			System.out.println("value = " + set.value);
			System.out.println("rowSet (size="+ set.rowSet.size() + ") = " + set.rowSet);
			System.out.println("colSet (size="+ set.colSet.size() + ") = " + set.colSet);
		}
		
	}

	public void printSet(String path) throws IOException {
		BufferedWriter bf = new BufferedWriter(new FileWriter(new File(path)));
		for(ColRowSet set: colRowSet){
			bf.write(set.value+"\n");
			for(Integer row:set.rowSet){
				bf.write(row+" ");
			}
			bf.write("\n");
			for(Integer col:set.colSet){
				bf.write(col+" ");
			}
			bf.write("\n");
		}
		System.out.println("Result has been printed in data/ROWCOL.txt");
		bf.flush();
		bf.close();
	}
}


class ColRowSet implements Comparable<ColRowSet>{
	double value;
	int size;
	HashSet<Integer> colSet;
	HashSet<Integer> rowSet;
	
	
	ColRowSet(double value,HashSet<Integer> colSet,HashSet<Integer> rowSet){
		this.value = value;
		this.colSet = colSet;
		this.rowSet = rowSet;
		this.size = colSet.size() * rowSet.size();
	}

	@Override
	public int compareTo(ColRowSet o) {
		if(this.size == o.size){
			return 1;
		}
		return -Integer.valueOf(this.size).compareTo(o.size);
	}
	
	
}


class IndexComparator implements Comparator<Integer>{
	int[] originalArray;
	IndexComparator(int[] originalArray){
		this.originalArray = originalArray;
	}
	
	public Integer[] indexGenerator(){
		Integer[] indexes = new Integer[originalArray.length];
		for(int i = 1;i<indexes.length;i++){
			indexes[i] = i;
		}
		return indexes;
	}
	
	@Override
	public int compare(Integer o1, Integer o2) {
		return -1 * Integer.valueOf(originalArray[o1]).compareTo(Integer.valueOf(originalArray[o2]));
	}

}

