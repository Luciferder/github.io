package cn.uestc.coclustering;


import Jama.Matrix;
import Jama.SingularValueDecomposition;
import cn.uestc.database.SyncObject;
import cn.uestc.patternSearching.PatternSearching;

import javax.swing.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;

//
//import be.hogent.tarsos.lsh.families.DistanceMeasure;
//import be.hogent.tarsos.lsh.families.EuclideanDistance;
//import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;




public class CoSync{


	public int num;
	public int dim;
	public double[][] W;
	public double[][] H;
	public ArrayList<SyncObject> data;
	public double alpha = 0.5;
	public double[][] Rc_record;
	private int looptimes;

	public CoSync() {

	}


	public double EuclideanDist(double[] dis){

		double val = 0.0;
		for(int i=0;i<dis.length;i++){
			val = val + dis[i]*dis[i];
		}
		double dist = Math.sqrt(val);
		return dist;
	}


	public double[][] pca(double[][] data){
		double[][] res;
		int dimdim = data[0].length;
		int numnum = data.length;
		HashSet<Integer> NN;
		Matrix mat = new Matrix(data);
		double [][] datacopy = mat.getArrayCopy();
		for(int j=0;j<datacopy[0].length;j++){
			double temp = 0;
			for(int i=0;i<datacopy.length;i++){
				temp += datacopy[i][j];
			}
			temp /= datacopy.length;
			for(int i=0;i<datacopy.length;i++){
				datacopy[i][j] -= temp;
			}
		}
		mat = new Matrix(datacopy);
		SingularValueDecomposition svd = new SingularValueDecomposition(mat);
		Matrix V = svd.getV();
		Matrix reducedData = mat.times(V.getMatrix(0,dimdim-1,0,15));

		res = reducedData.getArray();
		return res;
	}




	public HashSet<Integer> eNN(double e, int p, double[][] data, int loopNum, ArrayList<HashSet<Integer>> RowsNeighbors){
		int dim = data[0].length;
		int num = data.length;
		HashSet<Integer> NN;
		if( loopNum == 1){
			NN = new HashSet<Integer>();
			for(int i=0;i<num;i++){
				double tmp = Euclidean(data[p],data[i]);
				if(tmp < e && p != i){									//gcm:闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔告灮閹风兘鏁撻弬銈嗗闁跨喓娈曠涵閿嬪闁跨喐鏋婚幏鐑芥晸閻ㄥ棛銆嬮幏鐑芥晸閺傘倖瀚归柨鐔哄嵆濮ｆ棑缍囬幏锟�
					NN.add(i);   //if distance < e then add as the nearest node
				}
			}

		}else{
			NN = RowsNeighbors.get(p);
		}

		return NN;
	}










	public void printt(double[][] mat){
		File myfile = new File(Parameter.path + "tiaoshi.txt");
		try {
			FileWriter fw = new FileWriter(myfile);
			BufferedWriter bw = new BufferedWriter(fw);
			for(int k =0;k< mat.length;k++){									//xuyaogai
				for(int j=0;j<mat[0].length;j++){
					bw.write(String.valueOf(mat[k][j])+ " ");
				}
				bw.write("\n");
			}
			bw.write("\n");
			bw.close();
			fw.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public void printt(double[][] mat,String filepath,boolean append){
		File myfile = new File(filepath);
		try {
			FileWriter fw = new FileWriter(myfile,append);
			BufferedWriter bw = new BufferedWriter(fw);
			for(int k =0;k< mat.length;k++){									//xuyaogai
				for(int j=0;j<mat[0].length;j++){
					bw.write(String.valueOf(mat[k][j])+ " ");
				}
				bw.write("\n");
			}
			bw.write("\n");
			bw.close();
			fw.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public void printt(Number mat,String filepath,boolean append){
		File myfile = new File(filepath);
		try {
			FileWriter fw = new FileWriter(myfile,append);
			BufferedWriter bw = new BufferedWriter(fw);

			bw.write(String.valueOf(mat)+ " ");
			bw.write("\n");

			bw.close();
			fw.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public void printt(double[] mat,String filepath,boolean append){
		File myfile = new File(filepath);
		try {
			FileWriter fw = new FileWriter(myfile,append);
			BufferedWriter bw = new BufferedWriter(fw);
			for(int k =0;k< mat.length;k++){									//xuyaogai
				bw.write(String.valueOf(mat[k])+ " ");
			}
			bw.write("\n");
			bw.close();
			fw.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}



	public double Euclidean(double[] x, double[] y){

		double val = 0.0;
		for(int i=0;i<x.length;i++){
			val = val + (x[i]-y[i])*(x[i]-y[i]);
		}
		double dist = Math.sqrt(val);
		//System.out.println("Test: " + dist);
		return dist;
	}


	public void saveData(ArrayList<SyncObject> data, String fn) throws IOException {
		//DecimalFormat df = new DecimalFormat("###.000");
		int len = data.size();
		int dim = data.get(0).data.length;
		FileWriter fw = new FileWriter (new File(fn));
		BufferedWriter bw = new BufferedWriter(fw);
		for(int i=0;i<len;i++){
			for(int j=0; j<dim;j++){
				bw.write(((data.get(i).data[j])+"\t"));
			}

			//fout.write(((Integer)(data.get(i).label)+"\t").getBytes());

			bw.newLine();
		}
		bw.flush();
		bw.close();
		fw.close();

		bw = new BufferedWriter(new FileWriter(new File(Parameter.RCrecord)));
		for(int i = 0;i<looptimes;i++){
			bw.write(Rc_record[0][i] + " ");
		}
		bw.write("\n");
		for(int i = 0;i<looptimes;i++){
			bw.write(Rc_record[1][i] + " ");
		}
		bw.flush();
		bw.close();


	}

	public ArrayList<SyncObject> loadData(String fn, boolean normFlag, String sp) throws IOException {

		ArrayList<SyncObject> data = new ArrayList<SyncObject>();
		int num = 0;
		try {
			File mFile = new File(fn);
			FileReader fr = new FileReader(mFile);
			BufferedReader br = new BufferedReader(fr);
			String line;
			while((line=br.readLine())!=null){
				line = line.trim();
				String[] strs = line.split(sp);
				int dim = strs.length;
				if(dim == 2){						//   The matrix size on the head of file.
					num = Integer.parseInt(strs[0]);
					dim = Integer.parseInt(strs[1]);
					continue;
				}
				double[] temp = new double[dim];
				for(int i=0;i<dim;i++){
					temp[i] = Double.parseDouble(strs[i]);
				}
				SyncObject obj = new SyncObject(num,temp);
				data.add(obj);
				num = num + 1;
			}
			br.close();
			fr.close();

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		//System.out.println(numInit);
		this.num = data.size();
		this.dim = data.get(0).data.length;
		if(normFlag){
			data = norm(data, fn, sp, Parameter.crossNormFlag);
			ArrayList<SyncObject> data_copy = new ArrayList<SyncObject>(data);
			data_copy = precisionControl(data_copy);
			if(Parameter.crossNormFlag){
				saveData(data_copy, fn.substring(0, fn.length()-4) + "CrossNorm.txt");
			}else{
				saveData(data_copy, fn.substring(0, fn.length()-4)+"_Norm.txt");
			}

		}

		System.out.println(data.size()+","+data.get(0).data.length);
		return data;

	}

	public ArrayList<SyncObject> norm(ArrayList<SyncObject> data, String fn, String sp, boolean cross_norm){
		int n = data.size();
		int d = ((SyncObject)data.get(0)).data.length;
		double[] max = new double[d];
		double[] min = new double[d];

		for(int i=0;i<d;i++){
			max[i]= -Double.MAX_VALUE;
			min[i]= Double.MAX_VALUE;
		}


		for(int i=0 ;i< n;i++ ){
			for(int j = 0 ;j < d ;j++){
				max[j] = (max[j] < data.get(i).data[j]) ? data.get(i).data[j] : max[j];
				min[j] = (min[j] > data.get(i).data[j]) ? data.get(i).data[j] : min[j];
			}
		}

		if(cross_norm){
			for(int i=0; i<d; i++){
				double col_mean = 0;
				for(int j=0; j<n;j++){
					col_mean += data.get(j).data[i];
				}
				col_mean /= n;
				for(int j=0;j<n;j++){
					data.get(j).data[i] /= col_mean;
				}
			}
			//until now, the data have divided by their colomn mean
			for(int i=0; i<n ;i++){
				double row_mean = 0;
				for(int j=0; j<d; j++){
					row_mean += data.get(i).data[j];
				}
				row_mean /= d;
				double temp = 0;
				for(int j=0; j<d; j++){
					temp += (data.get(i).data[j] - row_mean) * (data.get(i).data[j] - row_mean);
				}
				temp = Math.sqrt(temp);
				if(0 == temp) JOptionPane.showMessageDialog(null, "alert", "divided by 0!", JOptionPane.ERROR_MESSAGE);
				for(int j=0; j<d; j++){
					data.get(i).data[j] = (data.get(i).data[j] - row_mean)/temp;
				}
			}
		}

		//Normalize the data set to [0, pi/2] for each dimension
		else{
			for(int i=0;i<n;i++){
				for(int j=0;j<d;j++){
					double temp = (Double)((SyncObject)data.get(i)).data[j];
					if(max[j]!=min[j]){
						//temp = 0.5*Math.PI*(temp-min[j])/(max[j]-min[j]);
						temp = (temp-min[j])/(max[j]-min[j]);
					}else
						temp = max[j];
					((SyncObject)data.get(i)).data[j] = temp;
				}
			}
		}

		return data;
	}





	public double dist(double[] al1, double[] al2){
		double res = 0.0f;

		if(al1.length!=al2.length) return 0.0f;
		else{
			double[] diss = new double[al1.length];
			for(int d=0;d<al1.length;d++){
				diss[d] = (Double)(al1[d])-(Double)(al2[d]);
			}
			res = EuclideanDist(diss);
		}

		return res;
	}

	public double dist(double[] al1, double[] al2, double[] decay){
		double res = 0.0f;

		if(al1.length!=al2.length) return 0.0f;
		else{
			double[] diss = new double[al1.length];
			for(int d=0;d<al1.length;d++){
				diss[d] = ((Double)(al1[d])-(Double)(al2[d])) * decay[d];
			}
			res = EuclideanDist(diss);
		}
		return res;
	}




	public double kNNArray(double data[][], int k){
		double res = 0.0f;

		// check inputs for validity
		if(data.length == 0 || k<=0) return 0.0f; // bail on bad input
		for(int s=0;s<data.length;s++){
			double[] d = new double[k];
			int[] idx = new int[k];
			int n = 0; // number of element in the res
			double dd = dist(data[s],data[0]); // load first one into list
			idx[n] = 0;
			if(s == 0){																		 //gcm: 闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔告灮閹风兘鏁撻弬銈嗗闁跨喓娈曠涵閿嬪闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔告灮閹风兘鏁撻惃鍡欍�閹风兘鏁撻弬銈嗗
				dd = dist(data[0],data[1]);
				idx[n] =1;
			}
			d[n++] = dd;
			// go through all other data points
			for(int i = 1;  i<data.length; i++){
				if(i == s) continue;															 //gcm: 闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔告灮閹风兘鏁撻弬銈嗗闁跨喓娈曠涵閿嬪闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔告灮閹风兘鏁撻惃鍡欍�閹风兘鏁撴鐑樻灮閹凤拷
				dd = dist(data[s],data[i]);
				if( n<k || d[k-1] > dd){ //add one
					if(n<k){
						idx[n]= i;
						d[n++] = dd;

					}
					int j = n-1;
					while(j>0 && dd < d[j-1]){ // slide big data up
						d[j] = d[j-1];
						idx[j] = idx[j-1];
						j--;
					}
					idx[j] = i;
					d[j] = dd;
				}
			}
			res = res + d[k-1];
		}
		return res/data.length;
	}

	public double[][] sampling(ArrayList<SyncObject> src, double rate, boolean transpose){
		double[][] data;
		if(transpose){
			data = new double[dim][num];
			for(int i=0;i<dim;i++){
				for(int j=0;j<num;j++){
					data[i][j] = src.get(j).data[i];
				}
			}
		}else{
			data = new double[num][dim];
			for(int i=0;i<num;i++){
				for(int j=0;j<dim;j++){
					data[i][j] = src.get(i).data[j];
				}
			}
		}

		return data;





//    	double[][] result;
//
//    	if(transpose){
//           	int num = src.size();
//        	int dim = src.get(0).data.length;
//	    	double[][] data = new double[dim][num];
//	    	for(int i=0;i<dim;i++){
//	    		for(int j=0;j<num;j++){
//	    			data[i][j] = src.get(j).data[i];
//	    		}
//	    	}
//
//        	int numm = (int)(data.length *rate);
//        	int dimm = data[0].length;
//        	result = new double[numm][];															//gcm:闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔告灮閹风兘鏁撻弬銈嗗闁跨喐鏋婚幏宄帮拷闁跨喐鏋婚幏鐑芥晸缂佺偠顕滈幏鐑芥晸閺傘倖瀚圭�鐐烘晸缂佺偛鍤栭幏鐑芥晸閺傘倖瀚归崡鐘绘晸閿燂拷
//
//        	for(int i=0;i<numm;i++){
//        		Random rand = new Random();
//        		int n = rand.nextInt(data.length-1);
//        		result[i] = data[n];
//        		//result[i] = data[i];
//        	}
//
//
//    	}else{
//        	int num = (int)(src.size()*rate);
//        	int dim = src.get(0).data.length;
//        	result = new double[num][];																//gcm:闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔告灮閹风兘鏁撻弬銈嗗闁跨喐鏋婚幏宄帮拷闁跨喐鏋婚幏鐑芥晸缂佺偠顕滈幏鐑芥晸閺傘倖瀚圭�鐐烘晸缂佺偛鍤栭幏鐑芥晸閺傘倖瀚归崡鐘绘晸閿燂拷
//
//        	for(int i=0;i<num;i++){
//        		Random rand = new Random();
//        		int n = rand.nextInt(src.size()-1);
//        		result[i] = src.get(n).data;
//        		//result[i] = src.get(i).data;
//        	}
//    	}
//
//    	return result;

	}




	public ArrayList<SyncObject> precisionControl(ArrayList<SyncObject> data2){		//闁跨喐鏋婚幏鐑芥晸閺傘倖瀚归柨鐔烘畷椤撱劍瀚归柨鐔告灮閹风柉甯㈤柨鐔告灮閹风兘鏁撻弬銈嗗濞寸媭鍨介幏鐑芥晸閺傘倖瀚归柨鐕傛嫹
		DecimalFormat df = new DecimalFormat(Parameter.precision);
		for(int i = 0;i<num;i++){
			for(int j =0;j<dim;j++ ){
				data2.get(i).data[j] = Double.valueOf(df.format(data2.get(i).data[j]));
			}
		}
		return data2;
	}

	public ArrayList<SyncObject> CoClusteringNew(ArrayList<SyncObject> data, double K1, double K2){
		num = data.size();
		dim =data.get(0).data.length;
		double[][] ori = new double[num][dim];
		for(int i=0;i<num;i++){
			for(int j=0;j<dim;j++){
				ori[i][j] = data.get(i).data[j];
			}
		}
		Matrix mat = new Matrix(ori);


		int loopNum = 0;
		ArrayList<HashSet<Integer>> RowsNeighbors = new ArrayList<HashSet<Integer>>();
		ArrayList<HashSet<Integer>> ColsNeighbors = new ArrayList<HashSet<Integer>>();
		Matrix changeMat;
		double[][] decay = new double[num][dim];
		double[][] decayT = new double[dim][num];
		double[][] decay1 = new double[num][dim];
		double[][] decay1T = new double[dim][num];
		double[][] decay2 = new double[num][];
		double[][] decay2T = new double[dim][];
		double preRc1 = 0.0;
		double preRc2 = 0.0;

		while(true){
			double Rc1 = 0.0;
			double Rc2 = 0.0;
			changeMat = new Matrix(num,dim);
			int count1 = 0;
			loopNum += 1;

//			if(loopNum == Parameter.loopNum*2/3){
//				K1 = this.kNNArray(mat.getArray(),Parameter.K1);
//				K2 = this.kNNArray(mat.getArray(),Parameter.K2);
//			}


			for(int i1 = 0 ;i1< num;i1++){
				HashSet<Integer> EachRowNeighbor;
				EachRowNeighbor = eNN(K1, i1,W, loopNum,RowsNeighbors);							//Shao : ues this
				if(loopNum == 1){
					RowsNeighbors.add(EachRowNeighbor);
					decay2[i1] = new double[EachRowNeighbor.size()];
				}
//				if( loopNum == Parameter.loopNum*2/3){
//					if(i1 == 0){
//						RowsNeighbors = new ArrayList<>();
//						printt(mat.getArray());
//					}
//					RowsNeighbors.add(EachRowNeighbor);
//					decay2[i1] = new double[EachRowNeighbor.size()];
//				}

				//if(EachRowNeighbor.size() == 1) System.out.println(loopNum + "         "+i1 + "    " +  EachRowNeighbor.get(0));
				if(EachRowNeighbor.size()>=1){          //if the number of interaction nodes is more than 1
					Rc1 +=  Interaction_usingVariance_usingExponentialDecayNew(EachRowNeighbor, loopNum ,i1, mat.getArray(), changeMat.getArray(), decay[i1],decay1[i1],decay2[i1]);
					count1 ++;
				}
			}


			if(count1 != 0){
				Rc1 /= count1;
			}



			if(loopNum == 1){
				System.out.println("\n\n\n\nTranspose Process:");
			}

			Matrix matT = mat.transpose();
			Matrix changeMatT = new Matrix(dim,num);
			int count2 = 0;
			for(int i2 = 0 ;i2< dim;i2++){
				HashSet<Integer> EachColNeighbor;
				EachColNeighbor = eNN(K2, i2,H, loopNum,ColsNeighbors);

				if(loopNum == 1){
					ColsNeighbors.add(EachColNeighbor);
					decay2T[i2] = new double[EachColNeighbor.size()];
				}
//				if( loopNum == Parameter.loopNum * 2/3){
//					if(i2 == 0){
//						ColsNeighbors = new ArrayList<>();
//					}
//					ColsNeighbors.add(EachColNeighbor);
//					decay2T[i2] = new double[EachColNeighbor.size()];
//				}
				//if(EachColNeighbor.size() == 1) System.out.println(loopNum +"  "+ i2+ "    " +  EachColNeighbor.get(0));
				if(EachColNeighbor.size()>=1){          //if the number of interaction nodes is more than 1
					Rc2 += Interaction_usingVariance_usingExponentialDecayNew(EachColNeighbor,loopNum ,i2, matT.getArray(), changeMatT.getArray(),decayT[i2],decay1T[i2],decay2T[i2]);
					count2 ++;
				}
			}
			if(count2 != 0){
				Rc2 /= count2;
			}

			changeMat = changeMat.plus(changeMatT.transpose());
			changeMat = changeMat.times(alpha);
			mat = mat.plus(changeMat);

			Rc_record[0][loopNum - 1] = Rc1;
			Rc_record[1][loopNum - 1] = Rc2;
			System.out.println("[Weighted]: loopNum = " + loopNum + " Rc1 = " + Rc1 + ", Rc2 = " + Rc2 );
//		    if(loopNum >= Parameter.loopNum || (Rc1 > (1-Parameter.converge) && Rc2 >(1-Parameter.converge)) ||(Math.abs(Rc1 - preRc1)/preRc1 <Parameter.converge && Math.abs(Rc2 - preRc2)/preRc2 < Parameter.converge)){
//		    	break;
//		    }
			if(loopNum >= Parameter.loopNum || ( Math.abs(Rc1 - preRc1)<Parameter.converge && Math.abs(Rc2 - preRc2)<Parameter.converge)){
				this.looptimes = loopNum;
				break;
			}
			preRc1 = Rc1;
			preRc2 = Rc2;
			if(loopNum == 1){
				System.out.println("Neighbors size:");
				for(HashSet<Integer> pp : RowsNeighbors){
					System.out.print(pp.size() + " ");
				}
				System.out.println("");
				for(HashSet<Integer> pp : ColsNeighbors){
					System.out.print(pp.size() + " ");
				}
				System.out.println("");
			}


		}
//    	printt(decay,"result/tiaoshi.txt",true);
//    	printt(decayT,"result/tiaoshi.txt",true);
		//printt(VAriance,"result/VAriance.txt",false);
		//printt(Rc_record,Parameter.RcPath,false);	// Record the Order parameter in the file "Rc_record.txt".
		for(int i=0;i<num;i++){
			data.get(i).data = mat.getArray()[i];
		}
		return data;
	}




	public double Interaction_usingVariance_usingExponentialDecayNew(HashSet<Integer> enn, int loopNum,int idx, double[][] data, double[][] change,double[] decay, double[] decay1, double[] decay2){
		double Rc = 0.0;
		int dim = data[0].length;
		int len = enn.size();
		double[][] mat  = new double[len][];	//neighbors' matrix
		double[][] diffmat = new double[len][dim];
		int ii = 0;
		for(Integer i:enn){
			mat[ii] = data[i];
			for(int j = 0;j<dim;j++){
				diffmat[ii][j] = mat[ii][j] - data[idx][j];
			}
			ii++;
		}

		if(loopNum == 1 ){
			double[] dev = new double[dim];
			double[] dv = new double[len];

			double temp = 0.0;
			for(int i = 0;i<dim;i++){
				for(int j = 0;j<len;j++){
					dev[i] = dev[i] + Math.abs(diffmat[j][i]);
				}
				dev[i] = dev[i]/len;
				temp += dev[i];
			}

			double[] varArray = new double[dim];
			for(int i = 0;i<dim;i++){
				for(int j = 0;j<len;j++){
					varArray[i] += Math.pow((Math.abs(diffmat[j][i]) - dev[i]),2);
				}
				varArray[i] /= len;
			}
			double avg = temp/dim;

			double temp1 = 0.0;
			for(int i = 0;i<dim;i++){
				temp1 += (dev[i] - avg) * (dev[i]- avg);
			}

			double variance = temp1/dim;
			//System.out.println("mean = "+avg+"; variance"+variance);
			double maxv = -1.0;
			//System.out.println("");
			for(int i =0 ;i < dim;i++){
				if(dev[i]>avg+2.0*Math.sqrt(variance)){
					decay1[i] = 0;
					//System.out.print(i+",");
				}else{
					decay1[i] =  Math.exp(-Parameter.lambda1 *varArray[i]);
				}

				if(decay1[i]>maxv)
					maxv = decay1[i];
			}
			//System.out.println("");
			for(int i =0 ;i < dim;i++){
				decay1[i] =  decay1[i]/maxv;
				//System.out.print("[" + i + "]" + decay1[i]+ " ");
			}
			//System.out.println("");



			double temp2 = 0.0;
			double[] varArray2 = new double[len];
			for(int i = 0;i<len;i++){
				for(int j = 0;j<dim;j++){
					dv[i] = dv[i] + decay1[j] * Math.abs(diffmat[i][j]);
				}
				dv[i] =dv[i]/dim;
				for(int j = 0;j<dim;j++){
					varArray2[i] += Math.pow((Math.abs(diffmat[i][j]) - dv[i]),2);
				}
				varArray2[i] /= dim;
				temp2 += dv[i];
			}
			double avg2 = temp2/len;


			double temp22 = 0.0;
			for(int i = 0;i<len;i++){
				temp22 += (dv[i] - avg2) * (dv[i]- avg2);
			}
			double variance2 = temp22/len;
			//System.out.println(dv[0]+";mean = "+avg2+"; variance"+variance2);
			//System.out.print("\nobject id =" + idx+":");
			for(int i=0;i<len;i++){
				if(dv[i]>avg2+2.0*Math.sqrt(variance2)){
					//decay2[i] = 0;
					decay2[i] =  Math.exp(-Parameter.lambda2 * varArray2[i]);
					//System.out.print(enn.get(i)+"=,");
				}else{
					//System.out.print(enn.get(i)+"*,");
					decay2[i] =  Math.exp(-Parameter.lambda2 * varArray2[i]);
				}
			}
			//System.out.println("");


			double mv = -1.0;//decay2[i] = Math.exp(-Parameter.lambda2 * dv[i]);
			for(int i=0;i<len;i++){
				if(decay2[i]>mv)
					mv = decay2[i];
			}

			//System.out.println("");
			for(int i = 0;i<len;i++){
				decay2[i] = decay2[i]/mv;
				//System.out.print(decay2[i]+",");
			}

			System.out.print("");
		}


		for(int i = 0;i< len ;i++){
			double dis = dist(data[idx],mat[i],decay1);
			Rc += Math.exp(-dis);
		}

		for(int i = 0;i<len ;i++){
			for(int j = 0;j<dim;j++){
				//System.out.println("row="+decay2[i]+", dim="+decay1[j]);
				change[idx][j] += decay2[i]*(1.0/len)*Math.sin(diffmat[i][j]) * decay1[j];
			}
		}

		return Rc/len;

	}

	boolean loadWH() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File(Parameter.WPath)));
		String line;
		double[][] W = new double[num][];

		int cnt = 0;
		while(null != (line = br.readLine())){
			line = line.trim();
			String[] strs = line.split("\\s+");
			W[cnt] = new double[strs.length];
			for(int i = 0; i< strs.length; i++){
				W[cnt][i] = Double.parseDouble(strs[i]);
			}
			cnt ++;
		}
		if( cnt != num){
			return false;
		}

		double[][] H = new double[dim][];
		br = new BufferedReader(new FileReader(new File(Parameter.HPath)));
		cnt = 0;
		while(null != (line = br.readLine())){
			line = line.trim();
			String[] strs = line.split("\\s+");
			H[cnt] = new double[strs.length];
			for(int i = 0; i< strs.length; i++){
				String str = strs[i];
				H[cnt][i] = Double.parseDouble(str);
			}
			cnt ++;
		}
		if( cnt != dim){
			return false;
		}
		this.W = W;
		this.H = H;
		return true;
	}

	public static void main(String[] args) throws IOException, java.text.ParseException {
		CoSync cs = new CoSync();
		if(Parameter.onlyOutput == true){
			cs.data = cs.loadData(Parameter.result_filepath,false,"\\s+");
			cs.precisionControl(cs.data);
			cs.saveData(cs.data, CoSync.Parameter.result_filepath);
		}else{
			long begin = System.currentTimeMillis();

			cs.data = cs.loadData(Parameter.load_filepath,Parameter.normFlag,Parameter.sp);
			if(!cs.loadWH()){
				System.out.println("size of WH are not right!");
				return;
			}

			double range1 = cs.kNNArray(cs.W ,Parameter.K1);
			double range2 = cs.kNNArray(cs.H ,Parameter.K2);

//    	range1 = 2.5;
//    	range2 =2.5;

			System.out.println("Interaction range ="+range1+";"+range2);

			cs.Rc_record = new double[2][Parameter.loopNum];

//    	range1 =3.1; range2 = 3.1;

			cs.CoClusteringNew(cs.data, range1, range2);
			long end = System.currentTimeMillis();
			System.out.println("Time elapse= "+ (end-begin) + " ms.");
			cs.precisionControl(cs.data);
			cs.saveData(cs.data, Parameter.result_filepath);

			//System.out.println("K1 = " +range1 +"; K2 = "+range2);
		}

		PatternSearching ps = new PatternSearching(cs.data, Parameter.printrowlimit, Parameter.printcollimit);
		ps.getSet();
		ps.printSet(Parameter.rowcolPath);
//		PatternTable pt = new PatternTable(cs.data, Parameter.printrowlimit, Parameter.printcollimit);
//		pt.getSet();
//		pt.printSet(Parameter.rowcolPath);
	}

	public static class Parameter{
			static String sp = "\\s+";
			static String path = "data\\Lung\\";
			static String WPath = path + "W.txt";
			static String HPath = path + "H.txt";
			static String load_filepath = path + "localdata_norm.txt";//"data/data2wei.txt";// "data/Dataset_A1_Standar_Samples.csv";	//闁跨喍鑼庣涵閿嬪闁跨喐鏋婚幏宄板絿鐠侯垶鏁撻弬銈嗗
			static String result_filepath = path + "finaldata.txt";					//闁跨喐鏋婚幏鐑芥晸閺傘倖瀚规繛娴嬫寢閸戙倖瀚归柨鐕傛嫹
			static String rowcolPath = path + "ROWCOL.txt";
			static String RCrecord = path + "RCrecord";
			static boolean normFlag = false;
			static boolean crossNormFlag = false;

		static int K1 = 15;
		static int K2 = 10;
		static int loopNum = 50;
		static int printrowlimit = 5;
		static int printcollimit = 5;
		static double lambda1 = 100;
		static double lambda2 = 0;
		static String precision = "###.00";
		static double converge =  1e-4;




		//exp(lambda * variance(variant))
		static boolean onlyOutput = false;			//Do some analysis and output job ,not using the Co-Sync algorithm, instead using the results caculated previously.

	};

}

class Descend implements Comparator<Integer>{
	public int compare(Integer arg0, Integer arg1){
		return -arg0.compareTo(arg1);
	}
}





















