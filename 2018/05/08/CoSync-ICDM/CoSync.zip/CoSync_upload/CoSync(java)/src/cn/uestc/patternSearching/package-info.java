/**
 * 
 */
/**
 * @author Administrator
 * @
 */
package cn.uestc.patternSearching;