package cn.uestc.patternSearching;

import cn.uestc.database.SyncObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeSet;

/**
 * Created by Administrator on 2016/1/20.
 */

public class PatternTable {
    private final int num;
    private final int dim;
    private final int minDim;
    private final int minNum;
    private final double[][] data;
    HashSet<Double> valueList;
    int[][] mat;
    public int maxSize;
    private TreeSet<HashNode> colRowSet;
    double particularNumber;
    int[] colset;
    HashNode maxnode;
    HashNode[] bigTable;

    public PatternTable(ArrayList<SyncObject> data, int minNum, int minDim){
        this.num = data.size();
        this.dim = data.get(0).data.length;
        this.minDim = minDim;
        this.minNum = minNum;
        this.data = new double[num][];
        valueList = new HashSet<Double>();
        for(int i=0;i<data.size();i++){
            this.data[i] = new double[dim];
            for(int j = 0; j < dim;j++){
                this.data[i][j] = data.get(i).data[j];
                if(!valueList.contains(this.data[i][j])){
                    valueList.add(this.data[i][j]);
                }
            }
        }
        colRowSet = new TreeSet<HashNode>();
        for(double i : valueList){
            mat = new int[num][dim];
            colset = new int[num];
            bigTable = new HashNode[(1<<dim) - 1];
            particularNumber = i;
            maxSize = 0;
            maxnode = null;
            getMaxSize(particularNumber);
            if(maxnode != null){
                colRowSet.add(maxnode);
            }
        }


    }

    public int[][] getEachTable(double particularNumber){
        for(int i=0;i<data.length;i++){
            for(int j=0;j<data[0].length;j++){
                if(data[i][j] == particularNumber){
                    mat[i][j] = 1;
                    colset[i] += 1<<j;                    //���裡
                }
            }
        }

        return mat;
    }

    public void getMaxSize(double particularNumber){
        mat = getEachTable(particularNumber);
        runTable(mat);
    }



    public void runTable(int[][] mat){
        for(int i = 0;i<mat.length;i++){
            for(int j = i;j<mat.length;j++){
                int join = colset[i] & colset[j];
                if(join == 0){
                    continue;
                }
                int rowset = (1<<i)|(1<<j);
                if(bigTable[join] == null){
                    HashNode node = new HashNode(this.particularNumber,join,rowset);
                    bigTable[join] = node;
                }else{
                    bigTable[join].addRow(rowset);
                }
                if(bigTable[join].size > this.maxSize && bigTable[join].rown >= this.minNum && bigTable[join].coln >= this.minDim){
                    maxSize = bigTable[join].size;
                    maxnode = bigTable[join];
                }

            }
        }
    }

    public static void main(String[] argv){
        double[][] matrix = {
                {1,1,1,0,0},
                {0,1,1,0,1},
                {1,0,1,1,1},
                {1,0,0,1,1},
                {1,1,1,0,0},
                {1,1,1,0,1},
                {1,0,0,0,0},
                {1,1,1,0,0},
                {1,1,0,0,1},
                {0,1,1,1,0},
                {1,0,0,0,0},
                {1,0,0,0,0},
                {0,1,1,0,0}
        };
        ArrayList<SyncObject> data = new ArrayList<SyncObject>(10);
        for(int i = 0;i<matrix.length;i++){
            data.add(new SyncObject(i,matrix[i]));
        }

        PatternTable ps = new PatternTable(data,1,1);
        ps.getSet();
    }

    public void getSet(){
        System.out.println("Number of distinct values: " + colRowSet.size());
        int cnt = 1;
        for(HashNode node: colRowSet){
            System.out.println("\n======================================================================");
            System.out.println("["+ cnt++ +"]");
            System.out.println("size = " + node.size);
            System.out.println("value = " + node.value);
            HashSet<Integer> rowSet = valtoSet(node.rowset,true);
            HashSet<Integer> colSet = valtoSet(node.colset,true);
            System.out.println("rowSet (size="+ rowSet.size() + ") = " + rowSet);
            System.out.println("colSet (size="+ colSet.size() + ") = " + colSet);
        }
    }
    public void printSet(String path) throws IOException {
        BufferedWriter bf = new BufferedWriter(new FileWriter(new File(path)));
        for(HashNode node: colRowSet){
            bf.write(node.value+"\n");
            HashSet<Integer> rowSet = valtoSet(node.rowset,true);
            HashSet<Integer> colSet = valtoSet(node.colset,true);
            for(Integer row:rowSet){
                bf.write(row+" ");
            }
            bf.write("\n");
            for(Integer col:colSet){
                bf.write(col+" ");
            }
            bf.write("\n");
        }
        System.out.println("Result has been printed in data/ROWCOL.txt");
        bf.flush();
        bf.close();
    }

    public HashSet<Integer> valtoSet(int val,boolean isAddone){
        HashSet<Integer> res = new HashSet();
        for(int i = 0; val>0 ;i++){
            if((1 & val) == 1){
                if(isAddone)
                    res.add(i+1);
                else
                    res.add(i);
            }
            val >>= 1;
        }
        return res;
    }

}

class HashNode implements Comparable<HashNode>{
    double value;
    int size;
    int coln;
    int rown;
    int rowset;
    int colset; // ��λ����ֵ

    HashNode(double value, int colset, int rowset){
        this.colset = colset;
        this.value = value;
        this.rowset = rowset;
        this.coln = numberOfoOne(colset);
        this.rown = numberOfoOne(rowset);
        this.size = coln * rown;
    }

    public void addRow(int rowset){
        this.rowset |= rowset;
        this.rown = numberOfoOne(this.rowset);
        this.size = this.rown * this.coln;
    }


    private int numberOfoOne(int val){
        int n = 0;
        while(val > 0){
            if(1 == (1 & val)){
                n++;
            }
            val >>= 1;
        }
        return n;
    }
    private HashSet<Integer> valtoColset(int val){
        HashSet<Integer> res = new HashSet<Integer>();
        for(int i = 0; val>0 ;i++){
            if((1 & val) == 1){
                res.add(i);
            }
            val >>= 1;
        }
        return res;
    }

    @Override
    public int compareTo(HashNode o) {
        if(this.size == o.size){
            return 1;
        }
        return -Integer.valueOf(this.size).compareTo(o.size);
    }
}


