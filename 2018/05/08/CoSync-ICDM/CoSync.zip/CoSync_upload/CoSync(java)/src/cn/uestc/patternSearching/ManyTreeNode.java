package cn.uestc.patternSearching;

import java.util.Comparator;
import java.util.HashSet;
import java.util.PriorityQueue;


public class ManyTreeNode implements Comparable<ManyTreeNode> {
	private PriorityQueue<ManyTreeNode> childList;
	ManyTreeNode parent;
	private int nodeID;
	private int count;
	private int level;
	private HashSet<Integer> rowSet;
	public boolean lazy;
	private IndexComparator comparator;
//	public ManyTreeNode() throws InterruptedException{
//		this.childList = new TreeSet<Integer>();
//		count = 0;
//		System.out.println("[Warning!] You should have called the constructed function with parameters:(int parent, int nodeID)");
//		Thread.sleep(1000);
//	}
	
	public ManyTreeNode(int nodeID, Comparator<Integer> comparator){
		this.comparator = (IndexComparator)comparator;
		this.childList = new PriorityQueue<ManyTreeNode>();
		this.rowSet = new HashSet<Integer>();
		this.count = 1;
		this.nodeID = nodeID;
		this.lazy = false;
	}
	
	public int getID(){
		return nodeID;
	}
	
	public void setID(int id){
		nodeID = id;
	}
	
	public ManyTreeNode addChild(int childID, int row){
		ManyTreeNode child = new ManyTreeNode(childID,comparator);
		childList.add(child);
		child.level = level + 1;
		child.parent = this;
		child.rowSet.add(row);
		return child;
	}
	
	public ManyTreeNode addChild(ManyTreeNode child){
		childList.add(child);
		child.level = this.level + 1;
		child.lazy = true;
		child.parent = this;
		return child;
	}
	
	public void removeChild(int childID){
		for(ManyTreeNode node: childList){
			if(node.getID() == childID){ 
				childList.remove(node);
				node = null;
				return;
			}
		}
	}
	public void removeChild(ManyTreeNode child){
		childList.remove(child);
		child = null;
	}
	
	public int getCount(){
		return count;
	}
	
	public PriorityQueue<ManyTreeNode> getChildList(){
		return childList;
	}
	
	public int getLevel(){
		return level;
	}
	
	public void setLevel(int level){
		this.level = level; 
	}
	
	public HashSet<Integer> getRowSet(){
		return rowSet;
	}
	
	public HashSet<Integer> getColSet(){
		HashSet<Integer> colSet = new HashSet<Integer>(this.level);
		colSet.add(this.getID());
		ManyTreeNode pa = this.parent;
		while(pa.getID() != 0){
			colSet.add(pa.getID());
			pa = pa.parent;
		}
		return colSet;
	}
	
	public void addCount(int added, int row){
		count =count + added;
		this.rowSet.add(row);
	}
	
	public void addCount(int added, HashSet<Integer> rowSet){
		count =count + added;
		this.rowSet.addAll(rowSet);
	}

	public void removeRowSetMember(int removeid){
		this.rowSet.remove(Integer.valueOf(removeid));
	}


	
	/**
	 * @notation If not exist the chlid node id, then the method return NULL;
	 */
	public ManyTreeNode getChild(int id){
		for(ManyTreeNode child : childList){
			if(child.getID() == id){
				return child;
			}
		}
		return null;
	}
	
	
	public boolean containChild(int id){
		for(ManyTreeNode child : childList){
			if(child.getID() == id){
				return true;
			}
		}
		return false;
	}


	@Override
	public int compareTo(ManyTreeNode o) {
		return comparator.compare(this.nodeID, o.nodeID);
//		int temp = comparator.compare(this.nodeID, o.nodeID);
//		if(temp == 0){
//			return -1;
//		} else{
//			return temp;
//		}

	}
}

