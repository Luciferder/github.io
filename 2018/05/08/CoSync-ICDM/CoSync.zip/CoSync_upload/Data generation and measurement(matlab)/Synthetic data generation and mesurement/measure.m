function [pur,rpur,maxnn,maxlabelnum,totalnum]=purity(stdc,getc)

uid = unique(getc);
nc = length(uid);

pur = 0.0;
rpur = 0.0;
temp_value = 0.0;
value = 0.0;
for i=1:nc

    idx = find(getc==uid(i));
    sid = unique(stdc(idx));
    maxn = 0;
    for j=1:length(sid)
        n = length(find(stdc(idx)==sid(j)));
        if(n>maxn)
            maxn = n;
            temp_value = sid(j);
        end
    end
    
    pur = pur + maxn;
    if(uid(i)~=0)
        rpur = rpur + maxn;
        value = temp_value;
    end
end
pur = pur/length(stdc);
maxnn = rpur;
rpur = rpur/length(getc(getc~=0));
maxlabelnum = length(stdc(stdc == value));
totalnum = length(stdc);
end


