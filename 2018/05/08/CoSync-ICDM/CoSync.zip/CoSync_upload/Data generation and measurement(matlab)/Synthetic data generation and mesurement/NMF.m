function NMF(A,k)
    [m,n] = size(A);
    looptime = 20;

    W = rand(m,k);
    H = rand(n,k);
    for i=1:k
        factor1 = norm(W(:,i),2);
        W(:,i) = W(:,i)/factor1;
    end

    loop = 0;
    while 1
        for p=1:k
            W(:,p) =W(:,p) + (A*H(:,p) - W*H'*H(:,p))/(H(:,p)'*H(:,p));    
            W(:,p) = max(10^(-16),W(:,p));
        end
         %%update H(k)
        for p=1:k
            H(:,p) = H(:,p)+(A'*W(:,p) -H*W'*W(:,p))/(W(:,p)'*W(:,p)); 
            H(:,p) = max(10^(-16),H(:,p));
        end

        disp(strcat(num2str(loop+1),'MSE:', num2str(norm(W*H'-A)/norm(A))));

        if (loop>=looptime)
            break;
        end
        loop=loop+1;
    end

    figure(1); imagesc(A);
    title('2-d synthetic dataset','Color','k','fontsize',16,'fontname','Palatino Linotype');
    set(gcf,'Color',[1,1,1]);
    colorbar;
    colormap gray;
    
    figure(2); imagesc(W);
    title('W','Color','k','fontsize',16,'fontname','Palatino Linotype');
    set(gcf,'Color',[1,1,1]);
    colorbar;
    colormap gray;
    
    figure(3); imagesc(H);
    title('H','Color','k','fontsize',16,'fontname','Palatino Linotype');
    set(gcf,'Color',[1,1,1]);
    colorbar;
    colormap gray;

    save('W.txt','W','-ascii');
    save('H.txt','H','-ascii');
end
