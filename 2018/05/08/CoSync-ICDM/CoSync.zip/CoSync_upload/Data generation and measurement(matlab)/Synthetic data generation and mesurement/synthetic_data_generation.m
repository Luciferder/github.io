%This script generate the synthetic data matrix. The parameters of the Gaussian and Uniform distribution can be user-defined.
%%
mu1 = 0.3;
mu2 = 0.9;
mu3 = 1.3;
mu4 = 1.1;
mu5 = 0.5;
mu6 = 0.4;
sigma = 0.1;
m = 1000;
n = 1000;
data = rand(m,n)*pi/2;
data(1:200,1:400) = mu1 + sigma * randn(200,400);
data(1:200,401:700) = mu2 + sigma * randn(200,300);
data(201:450,701:1000) = mu3 + sigma * randn(250,300);
data(451:750,1:400) = mu4 + sigma * randn(300,400);
data(451:750,701:1000) = mu5 + sigma * randn(300,300);
data(751:1000,401:700) = mu6 + sigma * randn(250,300);
data(data < 0) = 0;
k = 3;


%%
figure(1);
imagesc(data);
title('2-d synthetic dataset','Color','k','fontsize',16,'fontname','Palatino Linotype');
set(gcf,'Color',[1,1,1]);
axis equal;
axis tight;
colorbar;
colormap gray;

%%
NMF(data,k);
[~,pcaVrow] = pca(data);
[~,pcaVcol] = pca(data');
pcaVrow(:,4:end) = [];
pcaVcol(:,4:end) = [];
save('data.txt','data','-ascii');
save('pcaVrow.txt','pcaVrow','-ascii');
save('pcaVcol.txt','pcaVcol','-ascii');
% labels = [zeros(600,1);ones(400,1)];
% H = load('H.txt');pre = kmeans(H,2);purity(pre,labels)
% pre = kmeans(pcaVcol,2);purity(pre,labels)